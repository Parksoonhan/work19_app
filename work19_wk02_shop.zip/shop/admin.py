from django.contrib import admin
from .models import Item # 이 말이 있어야 admin.py에서 models의 아이템을 가져올 수 있음

admin.site.register(Item)