from django.urls import path
from shop import views #.-> 같은 폴더 ,shop -> 아예 폴더 지정

urlpatterns = [
    path('',views.item_list), #넘어온게 아무것도 안남아 있으면 아이템 리스트를 보여라
]