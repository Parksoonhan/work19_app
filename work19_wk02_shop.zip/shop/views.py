from django.shortcuts import render
from shop.models import Item #shop에 있는 models.py 안의 Item을 가지고 오겠다

def item_list(request):
    items = Item.objects.all() #아이템에 있는 모든 객체를 한꺼번에 다 가져와라 sql로 따리면 셀렉트 올과 같은 뜻 Items란 변수에 담기
    return render(
        request, # 요청정보
        'shop/item_list.html', #shop 밑에 있는 item_list.html ,템플릿 이름
        {'item_list':items}) #템플릿에 전달할 정보를 사전형태