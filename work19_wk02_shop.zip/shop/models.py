from django.db import models

class Item(models.Model):
    name = models.CharField(max_length=20)
    desc = models.TextField(blank=True) #상품설명이 없어도 그냥 넘어가기
    created_at = models.DateTimeField(auto_now_add=True) # 등록된 시각 자동으로 넣어줌
    updated_at = models.DateTimeField(auto_now=True) #현재시각을 자동으로 넣어줌
