from django.contrib import admin
from django.urls import path,include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('shop/', include('shop.urls')) #shop/로 시작되면 자신이 처리한 부분은 빼고(shop/은 빼고)shop-urls.py로 보냄
]
