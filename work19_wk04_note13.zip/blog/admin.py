from django.contrib import admin
from blog.models import Post, Comment

# admin.site.register(Post)

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'short_content',
                    'count_viewed', 'created_at',
                    'updated_at']
    list_display_links = ['id', 'title']
    search_fields = ['title', ]
    list_filter = ['title', 'updated_at', ]

    def short_content(self, post):
        return post.content[:10]

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['id', 'post', 'short_message',]
    list_display_links = ['id', 'short_message']

    def short_message(self, comment):
        return comment.message[:10]