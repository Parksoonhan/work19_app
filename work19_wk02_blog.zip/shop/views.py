from django.shortcuts import render
from shop.models import Item

def item_list(request):
    items = Item.objects.all()
    return render(
        request,                    # 요청 정보
        'shop/item_list.html',    # 템플릿 이름
        {'item_list': items})      # 템플릿에 전달할 정보를 사전형태